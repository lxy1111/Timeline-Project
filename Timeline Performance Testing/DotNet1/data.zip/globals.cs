//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 911
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Runtime.Remoting;
    
    
    public partial class VuserClass {
        
        private ObjectHandle ObjectHandle_1;
        
        private Object Object_1;
    }
}

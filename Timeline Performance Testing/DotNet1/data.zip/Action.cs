//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 911
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Runtime.Remoting;
    
    
    public partial class VuserClass {
        
        public virtual int Action() {

			String assemblyName_1;
			assemblyName_1 = "PresentationFramework-SystemXml, Version=4.0.0.0, Culture=neutral, Pu" + 
			"blicKeyToken=b77a5c561934e089";
			lr.log("Event 1: Activator.CreateInstance(assemblyName_1, \"MS.Internal.SystemXmlExtension" +
			  "\");");
			ObjectHandle_1 = Activator.CreateInstance(assemblyName_1, "MS.Internal.SystemXmlExtension");

			lr.log("Event 2: ObjectHandle_1.Unwrap();");
			Object_1 = ObjectHandle_1.Unwrap();

			lr.think_time(9);

            return 0;
        }
    }
}
